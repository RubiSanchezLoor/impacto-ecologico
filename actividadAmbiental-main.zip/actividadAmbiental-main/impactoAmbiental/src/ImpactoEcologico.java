// Definición de la interfaz ImpactoEcologico
interface ImpactoEcologico {
    // Método para obtener el impacto ecológico
    double obtenerImpactoEcologico(double consumoEnergia, double emisionesCO2, int cantidadResiduos);
}